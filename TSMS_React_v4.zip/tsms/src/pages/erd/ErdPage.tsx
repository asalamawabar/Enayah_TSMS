// TODO: Full implementation — port from HTML version
export function ErdPage() {
  return <div style={{ padding: 20, color: 'var(--text)', fontSize: 14 }}>
    <h2 style={{ marginBottom: 12, fontWeight: 500 }}>صفحة erd</h2>
    <p style={{ color: 'var(--text2)' }}>هذه الصفحة جاهزة للتطوير في المرحلة القادمة.</p>
  </div>
}
